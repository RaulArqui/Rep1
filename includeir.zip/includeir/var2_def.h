#ifndef var2_def_h
#define var2_def
unsigned int var2;
#endif
