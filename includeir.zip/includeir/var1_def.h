#include <iostream>
unsigned int var1;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main1() {
	
	return 0;
}
