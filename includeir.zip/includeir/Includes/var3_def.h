#ifndef var3_def_h
#define var3_def
unsigned int var3;
#endif
